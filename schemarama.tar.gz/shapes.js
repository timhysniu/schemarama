const fs = require('fs');

const fullShacl = () => fs
  .readFileSync(`${__dirname}/validation/shacl/full.shacl`)
  .toString();

  const fullShex = () => fs
  .readFileSync(`${__dirname}/validation/shex/full.shex`)
  .toString();


module.exports = {
  fullShacl,
  fullShex,
}
